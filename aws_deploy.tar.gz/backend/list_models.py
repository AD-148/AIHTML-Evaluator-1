import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

def list_models():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("FAILURE: GEMINI_API_KEY not found in .env")
        return

    try:
        genai.configure(api_key=api_key)
        print("Listing available models...")
        for m in genai.list_models():
            if 'generateContent' in m.supported_generation_methods:
                print(m.name)
    except Exception as e:
        print("FAILURE: Could not list models.")
        print("Error:", str(e))

if __name__ == "__main__":
    list_models()
